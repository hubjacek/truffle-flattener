#!/usr/bin/env sh

CWD=$PWD

sudo rm -rf $CWD/data
rm -rf bor.ipc
