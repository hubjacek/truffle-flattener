#!/usr/bin/env sh

docker stop bor-test
docker rm bor-test
