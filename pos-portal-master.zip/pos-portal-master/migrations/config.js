module.exports = {
  // plasmaRootChain: '0x82a72315E16cE224f28E1F1fB97856d3bF83f010', // testnetv3
  plasmaRootChain: '0x2890bA17EfE978480615e330ecB65333b880928e', // mumbai
  stateReceiver: '0x0000000000000000000000000000000000001001'
}
